from flask import Flask
from flaskext.mysql import MySQL

mysql = MySQL()
app = Flask(__name__)
app.config['MYSQL_DATABASE_USER'] = 'root'
app.config['MYSQL_DATABASE_PASSWORD'] = ''
app.config['MYSQL_DATABASE_DB'] = 'bancos'
app.config['MYSQL_DATABASE_HOST'] = 'localhost'
mysql.init_app(app)

def encriptar(data):
    import hashlib
    m = hashlib.md5()
    m.update(data)
    return str(m.hexdigest())

@app.route("/")
def hello():
    return "Api TESE!"

@app.route("/calculoCajero")
def calculoCajero():
    empresa = request.args.get('empresa')
    tipoCajero = request.args.get('tipoCajero')
    query = '''SELECT nombre_banco, t_final - t_inicial as tiempo
    FROM bancos.cajeros, banco, tipo_cajeros where empresa = %s and id_tipoCajero = %s
    and fk_id_tipoC = id_tipoCajero and fk_tipobanco = id_banco group by nombre_banco''' % (empresa, tipoCajero)
    cursor = mysql.connect().cursor()
    cursor.execute(query=query)
    total = 0
    valores = []
    for (Campo1, Campo2) in cursor:
        dic = {
            'name': Campo1,
            'valor': Campo2
        }
        total = int(total) + int(Campo2)
        valores.append(dic)
    import json
    return json.dumps(valores)


@app.route("/calculoCaja")
def calculoCaja():
    empresa = request.args.get('empresa')
    tipoCaja = request.args.get('tipoCaja')
    query = '''SELECT nombre_banco, t_final - t_inicial as tiempo
FROM bancos.cajas, banco, tipo_cajas where empresa = %s and id_tipoCaja= %s
and fk_id_tipoC = id_tipoCaja and fk_tipobanco = id_banco group by nombre_banco order by tiempo''' % (empresa, tipoCaja)
    cursor = mysql.connect().cursor()
    cursor.execute(query=query)
    total = 0
    valores = []
    for (Campo1, Campo2) in cursor:
        dic = {
            'name': Campo1,
            'valor': Campo2
        }
        total = int(total) + int(Campo2)
        valores.append(dic)
    import json
    return json.dumps(valores)







from flask import request
@app.route("/Empresa")
def Empresa():
    cursor = mysql.connect().cursor()
    cursor.execute("SELECT * FROM bancos.empresa")
    data = []
    for (id, name) in cursor:
        dic= {
            'id': id,
            'name': name
        }
        data.append(dic)
    print data
    import json
    return json.dumps(data)

@app.route("/show")
def show():
    cursor = mysql.connect().cursor()
    cursor.execute("SELECT * FROM bancos.empresa")
    data = []
    for (id, name) in cursor:
        dic= {
            'id': encriptar(str(name)),
            'name': encriptar(str(id))
        }
        data.append(dic)
    print data
    import json
    return json.dumps(data)

@app.route("/tipoCaja")
def TipoCaja():
    cursor = mysql.connect().cursor()
    cursor.execute("SELECT * FROM bancos.tipo_cajas")
    data = []
    for (id, descripcion) in cursor:
        dic = {
            'id': id,
            'descripcion': descripcion
        }
        data.append(dic)
    print data
    import json
    return json.dumps({'tipoCajas': data})

@app.route("/requestCajas")
def requestCajas():
    empresa = request.args.get('empresa')
    print empresa
    query = "SELECT id_banco, nombre_banco FROM bancos.banco where empresa = %s" % str(empresa)
    cursor = mysql.connect().cursor()
    cursor.execute(query)
    data = ''
    for (id, nom) in cursor:
        data += nom+"_"
    print data
    import json
    return json.dumps(data)

@app.route("/requestCajass")
def requestCajass():
    empresa = request.args.get('empresa')
    print empresa
    query = "SELECT id_banco, nombre_banco FROM bancos.banco where empresa = %s" % str(empresa)
    cursor = mysql.connect().cursor()
    cursor.execute(query)
    data = ''
    for (id, nom) in cursor:
        data += encriptar(nom+"_")
    print data
    import json
    return json.dumps(data)

@app.route("/cajero")
def Cajeros():
    username = request.args.get('UserName')
    password = request.args.get('Password')
    cursor = mysql.connect().cursor()
    cursor.execute("SELECT * FROM bancos.banco")
    data = ''
    for (Campo1, Campo2, Campo3) in cursor:
        data = data + "Campo1: " + str(Campo1) + ", Campo2: " + str(Campo2) + ", Campo3: " + str(Campo3)
    print data
    import json
    return json.dumps({'data': data})

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000)